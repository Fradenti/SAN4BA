# SANvi 0.1.1.9000

* Elbo computed at the end of EVERY algorithm.
* Removed useless absolute value to check convergence condition, substituted by a warning.

# SANvi 0.1.1

* Changed `abs()` to `fabs()` in `.cpp` files, to resolve a compilation warning on `r-devel-linux-x86_64-debian-clang` machines
* Updated the GitHub actions for package checks

# SANvi 0.1.0

* Submitted to CRAN
* Released to the public the first official version

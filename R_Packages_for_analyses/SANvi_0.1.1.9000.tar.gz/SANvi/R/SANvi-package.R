## usethis namespace: start
#' @useDynLib SANvi, .registration = TRUE
## usethis namespace: end
NULL
## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL

#' @keywords internal
"_PACKAGE"

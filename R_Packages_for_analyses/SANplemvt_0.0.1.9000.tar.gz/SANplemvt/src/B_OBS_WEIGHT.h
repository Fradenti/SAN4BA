#ifndef B_OBS_WEIGHT
#define B_OBS_WEIGHT

#include <RcppArmadillo.h>

#include "A_AUX.h"


arma::vec sample_obs_cluster_mvt(const arma::mat& y,
                                 arma::vec clusterD_long,
                                 arma::mat omega,
                                 int K_iter, int maxL,
                                 arma::mat mu, // L x D
                                 arma::cube W);

arma::mat dirichlet_sample_obs_weights(arma::vec M_iter,
                                       arma::vec clusterD_long,
                                       double beta,
                                       int K_iter,
                                       int maxK, int maxL);

#endif

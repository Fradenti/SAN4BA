#include "E_CONCENTRATIONS.h"

// The following functions perform step 8 of Algorithm 1 of Denti et al. (2021):
// update distributional DP parameter
double sample_alpha(double old_alpha,
                    double hyp_alpha1, double hyp_alpha2,
                    int G , arma::vec S_iter)
{
  double out ;
  arma::vec uniques = arma::unique(S_iter) ;
  int distinct_k = uniques.n_elem;
  double log_eta = log( R::rbeta(old_alpha + 1, G) ) ;

  double Q = (hyp_alpha1 + distinct_k - 1) / (G * (hyp_alpha2 - log_eta)) ;
  double pi_eta = Q / (1 + Q) ;
  double u = R::runif(0,1) ;

  if (u < pi_eta) {
    out  = R::rgamma( hyp_alpha1 + distinct_k, 1/(hyp_alpha2 - log_eta) ) ;
  } else {
    out = R::rgamma( hyp_alpha1 + distinct_k - 1, 1/(hyp_alpha2 - log_eta) ) ;
  }

  return(out) ;
}

// log-prior of a vector of probabilities with Dirichlet prior distribution
double overcam_logprior_prob(arma::vec prob, double par)
{
  double out ;
  int K = prob.n_elem ;
  for(int i = 0; i < K; i++) { prob(i) = log(prob(i)) ; }
  out = lgamma( K * par ) - K * lgamma(par) + (par-1) * arma::accu(prob) ;
  return(out) ;
}

// log-prior on the hyperparameter of the Dirichlet distributions
// following Malsiner-Walli et al. (2016)
// alpha ~ Gamma(a, a*K) and beta ~ Gamma(b, b*L)
double overcam_logprior_par_prob(double par, int dirichlet_dim, double hyperpar)
{
  double out = R::dgamma(par, hyperpar, 1/(hyperpar * dirichlet_dim), true) ;
  return(out) ;
}


// log-posterior observational Dirichlet hyperparameter
double overcam_logpost_beta(double beta, arma::mat omega, double hyperpar)
{
  int L = omega.n_rows ;
  int K = omega.n_cols ;

  arma::vec tmp(K) ;
  for(int k = 0; k < K; k++) { tmp(k) = overcam_logprior_prob(omega.col(k), beta) ; }
  double out = arma::accu(tmp) + overcam_logprior_par_prob(beta, L, hyperpar) ;
  return(out) ;
}

// MH-step on observational Dirichlet hyperparameter
double overcam_MH_beta(double current_par, double eps, arma::mat omega, double hyperpar)
{
  double new_par ;
  double ratio ;
  new_par = R::rnorm( current_par, eps ) ;
  ratio = exp( overcam_logpost_beta(new_par, omega, hyperpar) - overcam_logpost_beta(current_par, omega, hyperpar) ) ;
  if(R::runif(0, 1) < ratio) current_par = new_par ;
  return(current_par) ;
}



// prior on alpha and beta
double fcam_logprior_alpha(double alpha,
                           double hyp_alpha1, double hyp_alpha2)
{
  double out ;
  // out = R::df(alpha, hyp_alpha1, hyp_alpha2, true) ;
  out = R::dgamma(alpha, hyp_alpha1, 1/hyp_alpha2, true) ;
  return(out) ;
}

// log-posterior for MH step on alpha and beta
double fcam_logpost_alpha(double alpha,
                          double hyp_alpha1, double hyp_alpha2,
                          arma::vec cluster,
                          int Kplus,
                          int Kiter)
{
  double out ;
  int N = cluster.n_elem ;

  double tmp = 0 ;
  for(int h = 0; h < Kplus - 1 ; h ++)
  {
    arma::uvec ind = find( cluster == h ) ;
    tmp = tmp + lgamma( ind.n_elem + alpha/Kiter ) - lgamma( 1 + alpha/Kiter ) ;
  }

  out = fcam_logprior_alpha(alpha, hyp_alpha1, hyp_alpha2) + Kplus * log(alpha) + lgamma(alpha) -
    lgamma(N + alpha) + tmp ;
  return(out) ;
}

double fcam_MH_alpha(double current_par, double eps_alpha,
                     double hyp_alpha1, double hyp_alpha2,
                     int Kplus, int Kiter,
                     arma::vec cluster)
{
  double new_par ;
  double ratio ;
  new_par = exp(R::rnorm( log(current_par), eps_alpha )) ;

  ratio = exp( fcam_logpost_alpha(new_par,
                                  hyp_alpha1, hyp_alpha2,
                                  cluster,
                                  Kplus, Kiter) -
                                    fcam_logpost_alpha(current_par,
                                                       hyp_alpha1, hyp_alpha2,
                                                       cluster,
                                                       Kplus, Kiter) ) ;
  if(R::runif(0, 1) < ratio) { current_par = new_par ; }
  return(current_par) ;
}

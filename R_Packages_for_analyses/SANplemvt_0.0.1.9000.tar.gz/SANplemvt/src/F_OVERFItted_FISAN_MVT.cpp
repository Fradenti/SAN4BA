#include <RcppArmadillo.h>
#include "B_OBS_WEIGHT.h"
#include "C_BASE_MEASURES.h"
#include "D_DISTR_WEIGHTS.h"
#include "E_CONCENTRATIONS.h"
#include <progress.hpp>
#include <progress_bar.hpp>

// [[Rcpp::export]]
Rcpp::List sample_overfisan_mvt_cpp(int nrep, // number of replications of the Gibbs sampler
                                  int burn,
                                  const arma::mat & y, // input data
                                  const arma::vec & group, // group assignment for each observation in the vector y
                                  int maxK, // maximum number of distributional clusters
                                  int maxL, // maximum number of observational clusters
                                  arma::rowvec mu0, // 1xD
                                  double beta0, // hyperparameters on the N-iG prior on the mean parameter, mu|sigma2 ~ N(m0, sigma2 / tau0)
                                  double nu0,
                                  arma::mat W0, // hyperparameters on the N-iG prior on the variance parameter, 1/sigma2 ~ Gamma(lambda0, gamma0)
                                  bool fixed_alpha, bool fixed_beta, // do you want fixed alpha or beta?
                                  double alpha, double beta, // Dirichlet parameters if fixed
                                  double hyp_alpha1, double hyp_alpha2, // hyperparameters of alpha ( par of the distributional DP )
                                  double hyp_beta, // hyperparameter of the Gamma prior for the observational Dirichlet
                                  arma::mat mu0_start, // starting point
                                  arma::cube W0_start,
                                  arma::vec M_start,
                                  arma::vec S_start,
                                  double alpha_start, double beta_start,
                                  double eps_beta, // MH step on beta
                                  bool progressbar
                                  )
{
  int N = y.n_rows ;
  int D = y.n_cols ;
  arma::mat  iW0 = arma::inv_sympd(W0);
  arma::vec unique_groups = arma::unique(group) ;
  int G = unique_groups.n_elem ;



  //
  // allocate output matrices
  arma::cube out_mu(maxL, D, nrep-burn, arma::fill::zeros) ; // L x D
  arma::field<arma::cube> out_W(nrep-burn);
  arma::mat out_S(G, nrep-burn) ;
  arma::mat out_M(N, nrep-burn) ;
  arma::mat out_pi(maxK, nrep-burn, arma::fill::zeros) ;
  arma::cube out_omega(maxL, maxK, nrep-burn, arma::fill::zeros) ;
  arma::vec out_alpha(nrep-burn) ; // DP parameter for the distributional weights
  arma::vec out_beta(nrep-burn) ; // Dirichlet parameter for the observational weights
  arma::vec out_maxK(nrep-burn) ;


  // initialization
  arma::mat current_mu = mu0_start;
  arma::cube current_W = W0_start ;
  arma::vec current_M = M_start ;
  arma::vec current_S = S_start ;
  int current_maxK = maxK ;
  
  arma::vec current_pi = arma::ones(maxK)/maxK ;
  arma::mat current_omega = arma::ones(maxL, maxK) / maxL ;

  Rcpp::List out_params ;
  Rcpp::List tmp_obs_cl ;
  Rcpp::List weights_slice_sampler ;


  //arma::vec u_D(G, arma::fill::zeros) ;
  double current_beta = 0;
  double current_alpha = 0;

  if(fixed_alpha) {
    out_alpha.fill(alpha) ;
    current_alpha = alpha_start ;
  } else {
    current_alpha = alpha_start ;
  }

  if(fixed_beta) {
    out_beta.fill(beta) ;
    current_beta = beta_start;
  } else {
    current_beta = beta_start ;
  }


  arma::vec clusterD_long(N) ;
  for(int i = 0; i < N; i++) { clusterD_long(i) = current_S( group(i)) ; }
  arma::vec xi(maxK) ;
  for(int k = 0; k < maxK; k++) { xi(k) = fun_xi(0.5, k+1) ; }

  bool warningK = false ; arma::vec iters_maxK(nrep) ; int countK = 0 ;

  // progress bar
  bool display_progress = progressbar ;
  Progress p(nrep, display_progress) ;

  // START
  for(int iter = 0; iter < nrep ; iter++)
  {
    if( Progress::check_abort() ) { return -1.0 ; }
    p.increment();

    /*---------------------------------------------*/
    /*
     *  UPDATE MIXTURE WEIGHTS
     */


    weights_slice_sampler = ficam_weights_update_slice_sampler(group,
                                                               current_S,
                                                               current_alpha,
                                                               xi,
                                                               maxK) ;
    //Rcpp::Rcout << 6.1;

    arma::vec tmp_pi = weights_slice_sampler["new_pi"] ;
    current_pi = tmp_pi ;

    int maxK_new = weights_slice_sampler["new_maxK"] ;
    current_maxK = maxK_new ;
    if(current_maxK >= maxK) {
      warningK = true ;
      iters_maxK(countK) = (iter + 1) ;
      countK++ ;
      current_maxK = maxK - 1 ; }

    arma::vec u_D = weights_slice_sampler["u_D"] ;
    current_omega = dirichlet_sample_obs_weights(current_M,
                                                 clusterD_long,
                                                 current_beta,
                                                 current_maxK,
                                                 maxK, maxL) ;
    
    /*---------------------------------------------*/

    /*---------------------------------------------*/
    /*
     *  UPDATE CLUSTER ASSIGNMENT
     */
    /* update distributional clusters S */
    current_S = slicedDP_sample_distr_cluster(group,
                                              current_M,
                                              current_pi, current_omega,
                                              u_D, xi,
                                              current_maxK) ;
    for(int i = 0; i < N; i++) { clusterD_long(i) = current_S( group(i) ) ; }
    
    /* update observational clusters M */
    current_M = sample_obs_cluster_mvt(y,
                                       clusterD_long,
                                       current_omega,
                                       current_maxK, maxL, //
                                       current_mu, current_W) ;

    /*---------------------------------------------*/


    /*---------------------------------------------*/
    /*
     *  UPDATE PARAMETERS
     */
    out_params = sample_model_parameters_mvt(y, current_M,
                                             maxL,
                                             mu0,
                                             beta0,
                                             nu0,
                                             W0,
                                             iW0) ;

    arma::mat tmp_mu = out_params["out_mu"] ;
    current_mu = tmp_mu ;

    arma::cube tmp_sigma2 = out_params["out_W"] ;
    current_W = tmp_sigma2 ;

    /*---------------------------------------------*/

    /*---------------------------------------------*/

    /*---------------------------------------------*/
    /*
     *  UPDATE DIRICHLET HYPER-PARAMETERS
     */
    /* sample alpha */
    if(!fixed_alpha) {
      current_alpha = sample_alpha(current_alpha,
                                   hyp_alpha1, hyp_alpha2,
                                   G, current_S) ;
    }

    /* sample beta */
    if(!fixed_beta) {
      current_beta = overcam_MH_beta(current_beta, eps_beta,
                                     current_omega, hyp_beta) ;
    }

    /*---------------------------------------------*/
    // END
    if(iter >= burn){
      int ind = iter-burn;
      //Rcpp::Rcout << ind << "\n";

      out_mu.slice(ind) = current_mu;
      out_W(ind) = current_W;
      //Rcpp::Rcout << "a";
      out_maxK(ind) = current_maxK;
      //Rcpp::Rcout << "b";

      out_alpha(ind) = current_alpha;
      out_beta(ind)  = current_beta;
      //Rcpp::Rcout << "c";

      out_pi.col(ind) = current_pi;
      out_omega.slice(ind) = current_omega;
      //      Rcpp::Rcout << "d";

      out_S.col(ind) = current_S;
      out_M.col(ind) = current_M;
      //      Rcpp::Rcout << "e";

    }
  }

  Rcpp::List warnings ;
  if(warningK) {
    warnings = Rcpp::List::create(Rcpp::Named("top_maxK") = iters_maxK.head(countK) );
  }

  return Rcpp::List::create(Rcpp::Named("mu") = out_mu,
                            Rcpp::Named("W") = out_W,
                            Rcpp::Named("obs_cluster") = out_M.t(),
                            Rcpp::Named("distr_cluster") = out_S.t(),
                            Rcpp::Named("pi") = out_pi.t(),
                            Rcpp::Named("omega") = out_omega,
                            Rcpp::Named("alpha") = out_alpha,
                            Rcpp::Named("beta") = out_beta,
                            Rcpp::Named("maxK") = out_maxK,
                            Rcpp::Named("warnings") = warnings);
}

#include "B_OBS_WEIGHT.h"

arma::vec sample_obs_cluster_mvt(const arma::mat& y,
                                 arma::vec clusterD_long,
                                 arma::mat omega,
                                 int K_iter, int maxL,
                                 arma::mat mu, // L x D
                                 arma::cube W)
{
  arma::vec obs_cluster_id = arma::linspace(0, maxL-1, maxL) ;
  int N = y.n_rows ;

  arma::vec probO(maxL) ;
  arma::vec out(N) ;
  // M_ij is categorical, with Pr(M_ij = l | S_j = k) = om_lk * Pr(y_ij | mu_l)
  for(int i = 0; i < N; i++)
  {
    for(int l = 0; l < maxL; l++) {
      probO(l) = log( omega( l, clusterD_long(i) ) ) +
                  log_dmvtnorm_precision( y.row(i), mu.row(l), W.slice(l) ) ;
    }
    probO =  probO - max(probO) ;
    probO = exp(probO) ;
    out(i) = sample_i(obs_cluster_id, probO) ;
  }

  return(out) ;
}

arma::mat dirichlet_sample_obs_weights(arma::vec M_iter,
                                       arma::vec clusterD_long,
                                       double beta,
                                       int K_iter,
                                       int maxK, int maxL)
{
  // as before,
  // maxL is the dimension of the observational Dirichlet rv, K_iter the current dimension of the distrib. rv
  // maxL x maxK is the size of the allocated matrix, and I need to fill only the first maxL x K_iter elements

  arma::mat out_omega(maxL, maxK, arma::fill::zeros) ;

  /* for each distributional cluster k, sample observational probabilities omega */
  arma::vec dir_param(maxL) ;
  for(int k = 0; k < K_iter; k++)
  {
    out_omega.col(k).fill(0) ;
    arma::uvec ind_clusterD_k = find(clusterD_long == k) ;
    arma::vec subcluster = M_iter.elem( ind_clusterD_k ) ;

    dir_param.fill(0) ;
    for(int l = 0; l < maxL ; l++)
    {
      arma::uvec subcluster_l = find( subcluster == l ) ;
      dir_param(l) = beta + subcluster_l.n_elem ;
    }
    out_omega(arma::span(0, maxL-1), arma::span(k)) = rdirichlet(dir_param) ;
  }

  return(out_omega) ;
}


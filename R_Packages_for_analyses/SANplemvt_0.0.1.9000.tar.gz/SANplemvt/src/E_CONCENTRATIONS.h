#ifndef E_CONCENTRATIONS
#define E_CONCENTRATIONS

#include <RcppArmadillo.h>

#include "A_AUX.h"

double sample_alpha(double old_alpha,
                    double hyp_alpha1, double hyp_alpha2,
                    int G , arma::vec S_iter);

double overcam_logprior_prob(arma::vec prob, double par);

double overcam_logprior_par_prob(double par, int dirichlet_dim, double hyperpar);

double overcam_logpost_beta(double beta, arma::mat omega, double hyperpar);

double overcam_MH_beta(double current_par, double eps, arma::mat omega, double hyperpar);


// prior on alpha and beta
double fcam_logprior_alpha(double alpha,
                           double hyp_alpha1, double hyp_alpha2);

// log-posterior for MH step on alpha and beta
double fcam_logpost_alpha(double alpha,
                          double hyp_alpha1, double hyp_alpha2,
                          arma::vec cluster,
                          int Kplus,
                          int Kiter);

double fcam_MH_alpha(double current_par, double eps_alpha,
                     double hyp_alpha1, double hyp_alpha2,
                     int Kplus, int Kiter,
                     arma::vec cluster);

#endif

#ifndef C_BASE_MEASURES
#define C_BASE_MEASURES

#include <RcppArmadillo.h>

#include "A_AUX.h"

// update model parameters <--- change if different likelihood
Rcpp::List sample_model_parameters_mvt(const arma::mat& y,
                                       arma::vec M_iter,
                                       int maxL,
                                       arma::rowvec m0,
                                       double beta0,
                                       double nu0,
                                       arma::mat W0,
                                       arma::mat iW0);

#endif

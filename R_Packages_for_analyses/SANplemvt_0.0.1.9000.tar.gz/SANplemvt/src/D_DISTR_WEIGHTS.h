#ifndef D_DISTR_WEIGHTS
#define D_DISTR_WEIGHTS

#include <RcppArmadillo.h>

#include "A_AUX.h"


Rcpp::List ficam_weights_update_slice_sampler(const arma::vec& group,
                                              arma::vec S_iter,
                                              double alpha,
                                              arma::vec xi,
                                              int maxK);

arma::vec slicedDP_sample_distr_cluster(const arma::vec& group,
                                         arma::vec M_iter,
                                         arma::vec pi, arma::mat omega,
                                         arma::vec u_D,
                                         arma::vec xi,
                                         int maxK_iter);


#endif

#include "C_BASE_MEASURES.h"

// update model parameters <--- change if different likelihood
Rcpp::List sample_model_parameters_mvt(const arma::mat& y,
                                       arma::vec M_iter,
                                       int maxL,
                                       arma::rowvec m0,
                                       double beta0,
                                       double nu0,
                                       arma::mat W0,
                                       arma::mat iW0)
{
  int D = y.n_cols;
  arma::mat tout_mu(D,maxL) ; // L x D
  arma::cube out_W(D,D,maxL) ;

  arma::rowvec new_m0(D) ;
  double new_beta0 ;
  double new_nu0;
  arma::mat new_iW0(D,D) ;
  arma::mat S(D,D);

  for(int l = 0; l < maxL ; l++)
  {
    arma::uvec M_l = find( M_iter == l ) ;
    int n_l = M_l.n_elem ;
    if( n_l > 0) {
      S.zeros();
      arma::mat Y_sub = y.rows(M_l);
      arma::rowvec ybar_l = arma::sum( Y_sub,0 )/n_l; // sum of y_i
      arma::mat diff_y = Y_sub - arma::repelem(ybar_l,n_l,1);
      for(int h=0; h<n_l; h++){
        S += (diff_y.row(h)).t() * (diff_y.row(h));
      }

      // new parameters
      new_nu0 = nu0 + n_l ;
      new_beta0 = beta0+n_l ;
      new_m0 = (beta0 * m0 + n_l*ybar_l)/new_beta0;
      new_iW0 = iW0 + S + n_l*beta0/(new_beta0) * (ybar_l-m0).t() * (ybar_l-m0) ;
      out_W.slice(l) = rwish_cpp(arma::inv_sympd(new_iW0),new_nu0);
      tout_mu.col(l) = rmvtnorm_cpp_precision( new_m0.t(), new_beta0 * out_W.slice(l) ) ;

    } else {
      // from prior
      out_W.slice(l) = rwish_cpp(W0,nu0);
      tout_mu.col(l) = rmvtnorm_cpp_precision( m0.t(), beta0 * out_W.slice(l) )  ;
    }
  }

  return Rcpp::List::create(Rcpp::Named("out_mu") = tout_mu.t(),
                            Rcpp::Named("out_W") = out_W);
}




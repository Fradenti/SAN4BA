#ifndef A_AUX
#define A_AUX

#include "RcppArmadillo.h"

arma::vec rdirichlet(arma::vec par);

arma::vec relabel_arma(arma::vec cluster);

int sample_i(arma::vec ids, arma::vec prob);

arma::mat rwish_cpp(arma::mat W0, double nu);

arma::vec rmvtnorm_cpp(arma::vec mu, arma::mat Sigma);

arma::vec rmvtnorm_cpp_precision(arma::vec mu, arma::mat Omega);

double fun_xi(double kappa, int i);

int compute_trunc(double u_min, double kappa);

arma::vec stick_breaking_v2(arma::vec beta_var);

double log_dmvtnorm_precision(arma::rowvec y,
                              arma::rowvec mu,
                              arma::mat Omega);

double lbeta(double a, double b);

double logprior_maxx(int maxx, double hyp_max1,
                     double hyp_max2, double hyp_max3);

double logpost_maxx(int Kiter,
                    double hyp_max1,
                    double hyp_max2,
                    double hyp_max3,
                    double alpha,
                    arma::vec& cluster,
                    int Kplus);

int fcam_sample_K(int maxK,
                  int Kplus,
                  double hyp_max1,
                  double hyp_max2,
                  double hyp_max3,
                  double d_par,
                  arma::vec cluster);

#endif

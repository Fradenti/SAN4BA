#include "A_AUX.h"
#include <RcppArmadilloExtensions/sample.h>

arma::vec rdirichlet(arma::vec par)
{
  int distribution_size = par.n_elem ;
  arma::vec out = arma::zeros(distribution_size) ;
  double sum_term = 0 ;

  // draw Gamma variables
  for (int j = 0; j < distribution_size; j++) {
    double gam = R::rgamma(par[j], 1.0) ;
    out(j) = gam ;
    sum_term += gam ;
  }
  // normalize
  for (int j = 0; j < distribution_size; j++) {
    out(j) = out(j)/sum_term ;
  }
  return(out) ;
}

arma::vec relabel_arma(arma::vec cluster)
{
  int n = cluster.n_elem ;
  arma::vec newlabels(n) ;
  int lab ;

  arma::vec uniquecl = arma::unique(cluster) ;
  int n_distinct = uniquecl.n_elem ;
  int maxcl = cluster.max() ;

  if( maxcl > (n_distinct - 1) ) {
    for(int k = 0; k < n_distinct ; k++) {
      lab = uniquecl[k] ;
      arma::uvec indlab = find(cluster == lab) ;
      for(int h = 0; h < indlab.n_elem; h++) { newlabels[indlab[h]] = k ; }
    }
  } else {
    newlabels = cluster ;
  }
  return(newlabels);
}


// sample fun
int sample_i(arma::vec ids, arma::vec prob)
{
  int out ;
  out = Rcpp::RcppArmadillo::sample(ids, 1, false, prob)[0] ;
  return(out) ;
}


arma::mat rwish_cpp(arma::mat W0, double nu){
  int D = W0.n_cols;
  arma::mat U = chol(W0);
  arma::mat W(D,D);
  arma::mat At(D,D,arma::fill::zeros);
  // Bartlett's representation
  for(int i=0; i<D; i++){
    At(i,i) = sqrt(R::rchisq(nu - (i+1) +1));
    for(int j=(i+1); j<D; j++){
      At(i,j) = R::rnorm(0,1);
    }
  }
  return((At*U).t()*At*U);
}

arma::vec rmvtnorm_cpp(arma::vec mu, arma::mat Sigma){
  int D = Sigma.n_cols;
  arma::mat L = chol(Sigma,"lower");
  arma::vec z = Rcpp::rnorm(D,0,1);
  return(mu+L*z);
}

arma::vec rmvtnorm_cpp_precision(arma::vec mu, arma::mat Omega){
  int D = Omega.n_cols;
  arma::mat L = arma::trans(arma::inv(arma::trimatl(chol(Omega,"lower"))));
  arma::vec z = Rcpp::rnorm(D,0,1);
  return(mu+L*z);
}



// Compute slice coefficients
// We use a deterministic sequence as in Denti et al. (2021)
// See Sec. C1 of the Supplementary Material for details
double fun_xi(double kappa, int i)
{
  double out = log(1-kappa) + (i-1) * log(kappa) ;
  return(exp(out)) ;
}

// Truncating threshold of the slice sampler
// See Sec. C1 of the Supplementary Material of Denti et al. (2021) for details
int compute_trunc(double u_min, double kappa)
{
  int out ;
  out = floor( (log(u_min) - log(1 - kappa)) / log(kappa) ) ;
  return(out) ;
}


arma::vec stick_breaking_v2(arma::vec beta_var)
{
  int len = beta_var.n_elem ;
  arma::vec out(len) ;
  out(0) = beta_var(0) ;
  arma::vec cs_log_one_m_beta = arma::cumsum(log(1.0-beta_var));
  for(int k = 1; k < len; k++)
  {
    out(k) = exp( log(beta_var(k)) + cs_log_one_m_beta(k-1)) ;
  }
  return(out) ;
}


double log_dmvtnorm_precision(arma::rowvec y,
                              arma::rowvec mu,
                              arma::mat Omega){
  int D = Omega.n_cols;
  arma::vec diff = (y-mu).t();

  double res = - 0.5* D * log(2.0*arma::datum::pi) + .5 * log(arma::det(Omega)) -
    0.5 * arma::dot(diff, Omega*diff);

  return(res);
}


double lbeta(double a, double b)
{
  double out = 0;
  out = lgamma(a) + lgamma(b) - lgamma(a+b) ;
  return(out) ;
}

double logprior_maxx(int maxx, double hyp_max1,
                     double hyp_max2, double hyp_max3)
{
  double out ;
  out = lgamma( hyp_max1 + maxx - 1 ) + lbeta( hyp_max1 + hyp_max2, maxx - 1 + hyp_max3) -
    lgamma( hyp_max1 ) - lgamma( maxx ) - lbeta( hyp_max2, hyp_max3 ) ;
  return(out) ;
}


// log-posterior on max components
double logpost_maxx(int Kiter,
                    double hyp_max1,
                    double hyp_max2,
                    double hyp_max3,
                    double alpha,
                    arma::vec& cluster,
                    int Kplus)
{
  double out ;

  double tmp = 0 ;
  for(int h = 0; h < Kplus - 1 ; h ++)
  {
    arma::uvec ind = find( cluster == h ) ;
    tmp = tmp + lgamma( ind.n_elem + alpha/Kiter ) - lgamma( 1 + alpha/Kiter ) ;
  }

  out = logprior_maxx(Kiter, hyp_max1, hyp_max2, hyp_max3) +
    Kplus * log(alpha) + lgamma(Kiter + 1) - Kplus * log(Kiter) -
    lgamma(Kiter - Kplus + 1) + tmp ;

  return(out) ;
}


int fcam_sample_K(int maxK,
                  int Kplus,
                  double hyp_max1,
                  double hyp_max2,
                  double hyp_max3,
                  double d_par,
                  arma::vec cluster)
{
  int newK ;
  arma::vec K_id = arma::linspace( Kplus, maxK, maxK - Kplus + 1 ) ;

  arma::vec probunstd(K_id.n_elem) ;
  arma::vec logprob(K_id.n_elem) ;
  for(unsigned int k = 0; k < K_id.n_elem ; k++) {
    logprob(k) = logpost_maxx( Kplus + k ,
         hyp_max1, hyp_max2, hyp_max3,
         d_par, cluster, Kplus ) ;
  }
  // CHANGED HERE:
  //double minprob = prob.min() ;
  //for(unsigned int k = 0; k < K_id.n_elem ; k++)  {
  //  prob2(k) = exp(prob(k) - minprob) ;
  //}

  probunstd = exp(logprob - logprob.max()) ;

  newK = sample_i(K_id, probunstd/arma::accu(probunstd)) ;

  return(newK) ;
}

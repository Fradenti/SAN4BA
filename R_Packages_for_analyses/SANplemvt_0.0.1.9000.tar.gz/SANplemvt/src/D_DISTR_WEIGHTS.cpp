#include "D_DISTR_WEIGHTS.h"

Rcpp::List ficam_weights_update_slice_sampler(const arma::vec& group,
                                              arma::vec S_iter,
                                              double alpha,
                                              arma::vec xi,
                                              int maxK)
{
  arma::vec unique_groups = arma::unique(group) ;
  int G = unique_groups.n_elem ;
  arma::vec out_pi(maxK, arma::fill::zeros) ;

  int maxK_new ;
  arma::vec u_D(G) ;

  int a_k ; double b_k ;

  /*---------------------------------------------*/
  /*
   *  SAMPLE SLICE - uniform r.v.
   */
  /* distributional */
  for(int j = 0; j < G; j++)
  {
    u_D(j) = R::runif( 0, xi(S_iter(j)) ) ;
  }
  //Rcpp::Rcout << S_iter <<"\n----\n";
  //Rcpp::Rcout << u_D <<"\n----\n";
  int maxK_slice_tmp = compute_trunc(u_D.min(), 0.5) + 1 ;
  //Rcpp::Rcout << maxK <<"\n----\n"<<maxK_slice_tmp;
  maxK_new = std::min(maxK, maxK_slice_tmp) ;

  /*---------------------------------------------*/
  /*
   *  UPDATE MIXTURE WEIGHTS
   */
  /* sample distributional probabilities pi */
  /* (pi_1,...,pi_maxK) | . ~ DP */

  arma::vec v_k(maxK_new) ;
  arma::vec pi_k(maxK_new) ;
  for(int k = 0; k < maxK_new ; k++)
  {
    arma::uvec ind_k = find(S_iter == k) ;
    arma::uvec ind_mk = find(S_iter > k) ;

    a_k = 1 + ind_k.n_elem ;
    b_k = alpha + ind_mk.n_elem ;
    v_k(k) = R::rbeta(a_k, b_k) ;
  }
  pi_k = stick_breaking_v2 ( v_k ) ;
  out_pi(arma::span(0, maxK_new-1)) = pi_k ;


  return Rcpp::List::create(Rcpp::Named("new_maxK") = maxK_new,
                            Rcpp::Named("new_pi") = out_pi,
                            Rcpp::Named("u_D") = u_D);

}



arma::vec slicedDP_sample_distr_cluster(const arma::vec& group,
                                         arma::vec M_iter,
                                         arma::vec pi, arma::mat omega,
                                         arma::vec u_D,
                                         arma::vec xi,
                                         int maxK_iter)
{

  arma::vec unique_groups = arma::unique(group) ;
  int G = unique_groups.n_elem ;

  arma::vec distr_cluster_id = arma::linspace(0, maxK_iter-1, maxK_iter) ;
  arma::vec probD(maxK_iter) ;
  arma::vec out(G) ;
  double sumdens ;

  // S_j is categorical, with Pr( S_j = k | - ) = I(u_j < xi_k) pi_k/xi_k * ( om_1k^#(M_ij = 1) ... om_Lk^#(M_ij = L) )
  // hence the log is:  log(pi_k) - log(xi_k) + sum_l  #(M_ij = l) * log( om_lk )
  for(int j = 0; j < G; j++)
  {
    arma::uvec ind_group_j = find(group == j) ;  // restrict to observations in the j-th population
    arma::vec mixdens(ind_group_j.n_elem) ;

    for(int k = 0; k < maxK_iter; k++)  // I have to compute the prob for each k = 1,..., K_iter
    {
      for(int i = 0; i < ind_group_j.n_elem; i++) { mixdens(i) = log( omega(M_iter(ind_group_j(i)), k) ) ; }
      sumdens = arma::accu(mixdens) ;
      if(!arma::is_finite(sumdens)) { sumdens = log(0) ;}
      probD(k) =  log( pi(k) ) - log( xi(k) ) + sumdens + log(u_D(j) < xi(k));
    }
    double tmp = max(probD) ;
    for(int k = 0; k < maxK_iter; k++) {  probD(k) = probD(k) - tmp ; }
    probD = exp(probD) ;
    out(j) = sample_i(distr_cluster_id, probD) ;
  }

  return(out) ;
}






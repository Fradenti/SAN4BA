#' Sample fiSAN
#'
# sample_mvt_fiSAN <- function(nrep, burn, y, group,
#                              maxK = 50, maxL = 50,
#                              m0 = rep(0,ncol(y)),
#                              beta0 = 0.01,
#                              nu0 = ncol(y)+5,
#                              W0 = diag(ncol(y)),
#                              hyp_alpha1 = 1, hyp_alpha2 = 1,
#                              hyp_beta1 = 6, hyp_beta2 = 3,
#                              eps_beta = NULL,
#                              alpha = NULL, beta = NULL,
#                              warmstart = TRUE, nclus_start = NULL,
#                              mu_start = NULL, sigma2_start = NULL,
#                              M_start = NULL, S_start = NULL,
#                              alpha_start = NULL,
#                              beta_start = NULL,
#                              progress = TRUE,
#                              seed = NULL)
# {
#   group <- .relabell(group) - 1
#
#   if(is.null(seed)){seed <- round(stats::runif(1,1,10000))}
#   set.seed(seed)
#   D <- ncol(y)
#   L <- maxL
#   K <- maxK
#   params <- list(y = y,
#                  group = group,
#                  K = K,
#                  L = L,
#                  m0 = m0,
#                  beta0 = beta0,
#                  nu0 = nu0,
#                  W0 = W0,
#                  seed = seed)
#
#
#   if(!is.null(alpha)) { params$alpha <- alpha }
#   if(!is.null(beta)) { params$beta <- beta }
#   if(is.null(alpha)) { params$hyp_alpha1 <- hyp_alpha1 }
#   if(is.null(alpha)) { params$hyp_alpha2 <- hyp_alpha2 }
#   if(is.null(beta)) { params$hyp_beta1 <- hyp_beta1 }
#   if(is.null(beta)) { params$hyp_beta2 <- hyp_beta2 }
#
#   if(is.null(S_start)) { S_start <- rep(1:length(unique(group)))-1 }
#
#   # if the initial cluster allocation is passed
#   if(!is.null(M_start)) {
#     warmstart <- FALSE
#     M_start <- .relabell(M_start)
#
#     # and the mean is passed or the variance is passed don't do anything
#
#     # if the mean is not passed
#     if(is.null(mu_start)) {
#       mu0_start <- matrix(0, maxL, D)
#       for(l in unique(M_start)) {
#         mu0_start[l,] <- colMeans(y[M_start == l,])
#       }
#     }
#     # if the variance is not passed
#     if(is.null(sigma2_start)) {
#       W0_start <- array(diag(D),c(D,D,maxL))
#       for(l in unique(M_start)) {
#         W0_start[,,l] <- cov(y[M_start == l,])
#       }
#     }
#   } else {
#     # if the initial cluster allocation is not passed
#     # and you don't want a warmstart
#     if(!warmstart){
#       M_start <- sample(0:(maxL-2), length(y), replace = TRUE) # changed starting points
#       mu0_start <- matrix(0, maxL, D)
#       mu0_start[1,] <- colMeans(y)
#       W0_start <- array(diag(D),c(D,D,maxL))
#       W0_start[,,1] <- cov(y)
#       mu0_start  <-   t(apply(y, 2, function(q) stats::runif(maxL, min((q)),max((q)))))
#     }
#
#     # if the initial cluster allocation is not passed
#     # and you want a warmstart
#     if(warmstart){
#       mu0_start <- matrix(0, maxL, D)
#       W0_start <- array(diag(D),c(D,D,maxL))
#
#       if(is.null(nclus_start)) {
#         nclus_start <- min(c(maxL, 30))
#       }
#
#       M_start <- stats::kmeans(y,
#                                centers = nclus_start,
#                                algorithm="MacQueen",
#                                iter.max = 50)$cluster
#
#       nclus_start <- length(unique(M_start))
#       mu0_start[1:nclus_start,] <- t(sapply(1:nclus_start, function(x) colMeans(y[M_start == x,])))
#       for(l in 1:nclus_start){
#         W0_start[,,l] <- cov(y[M_start == l,])
#       }
#     }
#   }
#   M_start <- M_start-1
#
#   if(is.null(alpha_start)) { alpha_start <- rgamma(1, hyp_alpha1, hyp_alpha2) }
#   if(is.null(beta_start)) { beta_start <- rgamma(1, hyp_beta1, hyp_beta2) }
#
#   fixed_alpha <- F
#   fixed_beta <- F
#   if(!is.null(alpha) ) {
#     fixed_alpha <- T ;
#     alpha_start <- alpha ;
#     eps_alpha <- 1
#   } else { alpha <- 1 }
#   if(!is.null(beta) ) {
#     beta_start <- beta
#     fixed_beta <- T ;
#     eps_beta <- 1 } else { beta <- 1 }
#
#   if((fixed_beta == F)&(is.null(eps_beta))) {stop("Missing eps parameter for MH step on beta Please provide 'eps_beta' or a fixed 'beta' value.")}
#
#   start <- Sys.time()
#   out <- sample_ficam_mvt_cpp(nrep = nrep,burn = burn,
#                               y =  y,group =  group,
#                           maxK = maxK, maxL =  maxL,
#                           mu0 = m0,
#                           beta0 = beta0,
#                           nu0 = nu0,
#                           W0 = W0,
#                           fixed_alpha = fixed_alpha,
#                           fixed_beta = fixed_beta,
#                           alpha =  alpha, beta = beta,
#                           hyp_alpha1 =  hyp_alpha1, hyp_alpha2 = hyp_alpha2,
#                           hyp_beta1 =  hyp_beta1, hyp_beta2 =  hyp_beta2,
#                           mu0_start = mu0_start,
#                           W0_start = W0_start,
#                           M_start = M_start, S_start =  S_start,
#                           alpha_start = alpha_start,
#                           beta_start =  beta_start,
#                           eps_beta = eps_beta, progressbar = progress)
#   end <- Sys.time()
#
#   warnings <- out$warnings
#   out[12] <- NULL
#
#   out$distr_cluster <- out$distr_cluster + 1
#   out$obs_cluster <- out$obs_cluster + 1
#
#
#   if(length(warnings) == 2) {
#     output <- list( "model" = "fiSAN",
#                     "params" = params,
#                     "sim" = out,
#                     "time" = end - start,
#                     "warnings" = warnings)
#     warning("Increase maxL and maxK: all the provided mixture components were used. Check $warnings to see when it happened.")
#   } else if (length(warnings) == 1) {
#     if((length(warnings$top_maxK)>0) & (length(warnings$top_maxL)==0)) {
#       output <- list( "model" = "fiSAN",
#                       "params" = params,
#                       "sim" = out,
#                       "time" = end - start,
#                       "warnings" = warnings)
#       warning("Increase maxK: all the provided distributional mixture components were used. Check '$warnings' to see when it happened.")
#     }
#
#     if((length(warnings$top_maxK)==0) & (length(warnings$top_maxL)>0)) {
#       output <- list( "model" = "fiSAN",
#                       "params" = params,
#                       "sim" = out,
#                       "time" = end - start,
#                       "warnings" = warnings)
#       warning("Increase maxL: all the provided observational mixture components were used. Check '$warnings' to see when it happened.")
#     }
#   } else {
#     output <- list( "model" = "fiSAN",
#                     "params" = params,
#                     "sim" = out,
#                     "time" = end - start )
#   }
#
#   structure(output, class = c("SANmcmc", class(output)))
#
# }

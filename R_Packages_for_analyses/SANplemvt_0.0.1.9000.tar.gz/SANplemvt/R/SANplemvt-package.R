## usethis namespace: start
#' @useDynLib SANplemvt, .registration = TRUE
## usethis namespace: end
NULL
## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL

#' @keywords internal
"_PACKAGE"

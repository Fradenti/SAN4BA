#ifndef mvt_A_AUX
#define mvt_A_AUX
#include <RcppArmadillo.h>

double LogSumExp_cpp(arma::rowvec logX);

arma::colvec reverse_cumsum_cpp(arma::colvec X);

double log_Const_prod_gamma(int D, double nu);

double Const_sum_digamma(int D, double nu);

double logB_wish(arma::mat W, double nu, double log_Const_prod_gamma);

double ElogDetLambda(arma::mat W,
                     double Const_sum_digamma);

double  H_Lambda(arma::mat W, double nu,
                 double Const_sum_digamma,
                 double log_Const_prod_gamma);


#endif


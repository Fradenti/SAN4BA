#ifndef mvt_D_CAVI_UPDATES
#define mvt_D_CAVI_UPDATES

#include <RcppArmadillo.h>

#include "mvt_A_AUX.h"
#include "mvt_B_EXP_VALUES.h"


arma::mat Update_Vk_DP_conc_cpp(double E_b,
                                arma::mat RHO_jk);

// -----------------------------------------------------------------------------

arma::mat Update_beta_dirlk_cpp(arma::field<arma::mat> XI_ijl,
                                arma::mat RHO_jk,
                                arma::mat beta_lk);

// -----------------------------------------------------------------------------

arma::mat Update_RHOjk_cpp_fiSAN(arma::field<arma::mat> XI_ijl, // collection of  J objectes: nj*L matrices
                                 arma::colvec ElnPI_k,
                                 arma::mat beta_star_lk);

// -----------------------------------------------------------------------------

arma::colvec Update_s_concentration_par_fiSAN(arma::colvec a_tilde_Vk,
                                              arma::colvec b_tilde_Vk,
                                              arma::colvec conc_hyper);

// -----------------------------------------------------------------------------

Rcpp::List Update_THETAl_cpp_mvt(arma::field<arma::mat> Y_grouped,
                                 arma::field<arma::mat> XI_ijl,
                                 arma::colvec m0,
                                 double beta0,
                                 double nu0,
                                 arma::mat W0, 
                                 arma::mat iW0);
  
// -----------------------------------------------------------------------------
  
arma::field<arma::mat> Update_XIijl_cpp_fiSAN_mvt(arma::field<arma::mat> Y_grouped,
                                                  arma::mat RHO_jk,
                                                  arma::mat beta_star_lk,
                                                  arma::mat ml,
                                                  arma::colvec betal,
                                                  arma::colvec nul,
                                                  arma::cube Wl);
#endif


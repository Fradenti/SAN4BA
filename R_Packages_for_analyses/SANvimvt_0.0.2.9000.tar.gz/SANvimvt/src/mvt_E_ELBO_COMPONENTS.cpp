#include "mvt_E_ELBO_COMPONENTS.h"

// fiSAN specific - used by overcam as well

double elbo_diff_M_fiSAN(arma::field<arma::mat> XI_ijl,
                      arma::mat RHO_jk,
                      arma::mat beta_star_lk){
  
  int L = beta_star_lk.n_rows;
  int J = RHO_jk.n_rows;
  int K = RHO_jk.n_cols;
  
  arma::mat N_jl(J,L);
  arma::mat E_ln_omega(L,K);
  arma::colvec Z2(J);
  
  for(int k=0; k<K; k++){
    E_ln_omega.col(k) =
      E_log_DIR(beta_star_lk.col(k)); // L x K
  }
  for(int j=0; j<J; j++){
    N_jl.row(j) = arma::sum(XI_ijl(j),0); //J x L
    Z2(j) = arma::accu(XI_ijl[j] % log(XI_ijl[j] + 1e-12) );
  }
  
  arma::mat X_jl  = RHO_jk * E_ln_omega.t();
  double Z1 = accu( N_jl % X_jl);
  return(Z1- arma::accu(Z2));
}

// -----------------------------------------------------------------------------

double elbo_p_Y(arma::field<arma::mat> XI_ijl,
                arma::mat ml,
                arma::colvec betal,
                arma::colvec nul,
                arma::cube Wl,
                arma::cube Sl,    // D x D x L
                arma::mat Ybar,   // D x L
                arma::rowvec Nl){
  
  double Z = 0.0;
  int D = Wl.n_rows;
  int L = nul.n_rows;

  arma::vec CSD(L);
  arma::vec ELDL(L);
  arma::vec H(L);

  for(int l=0; l < L; l++){
    CSD(l)  = Const_sum_digamma(D, nul(l));
    ELDL(l) = ElogDetLambda(Wl.slice(l), CSD(l));
    
      Z += Nl(l) * 
          ( 
           ELDL(l) - D * (1.0/betal(l)) - 
           nul(l) * arma::trace( Sl.slice(l) * Wl.slice(l) ) - 
           nul(l) * arma::dot( (Ybar.col(l)-ml.col(l)), 
                   Wl.slice(l)*(Ybar.col(l)-ml.col(l)) ) -  
           D * log( 2.0 * arma::datum::pi) 
        );
      
    }
  
  return(.5*Z);
  
}

// -----------------------------------------------------------------------------

double elbo_diff_v_CP(arma::colvec a_tilde_k,
                   arma::colvec b_tilde_k,
                   double const b_tilde,
                   arma::colvec S_concDP){
  
  int K = a_tilde_k.n_rows;
  
  a_tilde_k.shed_row(K-1);
  b_tilde_k.shed_row(K-1);
  
  arma::colvec Y =
    E_log_beta(b_tilde_k,a_tilde_k) * ( b_tilde - 1.0 );
    
  double p1 = (K-1.0)  * ( R::digamma(S_concDP[0]) - log(S_concDP[1]) ) + arma::accu(Y);  
  double p2 = arma::accu(lbeta_normconst_vec_cpp(a_tilde_k,b_tilde_k) +
              E_log_beta(a_tilde_k,b_tilde_k) % (a_tilde_k - 1.0 )+
              E_log_beta(b_tilde_k,a_tilde_k) % (b_tilde_k - 1.0 ));
  
  return(p1-p2);
}

// ----------------------------------------------------------------------- 10.74

double elbo_p_THETA(arma::colvec m0, double beta0, double nu0, 
                    arma::mat W0, arma::mat iW0, 
                    double lCpl0, double LlogB0,
                    arma::mat ml,
                    arma::colvec betal,
                    arma::colvec nul, arma::cube Wl){
  
  int D = W0.n_rows;
  int L = betal.n_rows;
  
  arma::vec CSD(L);
  arma::vec LCPL(L);
  
  double p1   = 0.0;
  double ell1 = 0.0;
  double p4   = 0.0;
  
  
  for(int l = 0; l<L; l++){
    
    CSD(l)  = Const_sum_digamma(D, nul(l));
    LCPL(l) = log_Const_prod_gamma(D, nul(l));
    
    ell1   += ElogDetLambda(Wl.slice(l), CSD(l));
    p1     += nul(l) * arma::dot((ml.col(l)-m0) , 
                  Wl.slice(l) * ((ml.col(l)-m0)));
    p4     += nul(l) * arma::trace( iW0 * Wl.slice(l) );
    
  }
  
  double p0 = .5* (L * D * log( beta0/(2.0*arma::datum::pi) ) + 
                   ell1 - 
                   D * beta0 * arma::accu(1.0/(betal)) -
                   beta0 * p1 );
  
  
  double  Z =  LlogB0 + p0 + (nu0 - D - 1.0) * 0.5 * ell1 - 0.5 * p4;
  
  return(Z);
}

// ----------------------------------------------------------------------- 10.77

double elbo_q_THETA(arma::mat ml, arma::colvec betal,
                    arma::colvec nul, arma::cube Wl){
  
  int D = Wl.slice(0).n_rows; 
  int L = nul.n_rows;
  arma::vec CSD(L);
  arma::vec ELDL(L);
  arma::vec H(L);
  
  for(int l = 0; l<L; l++){
    CSD(l)  = Const_sum_digamma(D, nul(l));
    ELDL(l) = ElogDetLambda(Wl.slice(l), CSD(l));
    H(l)    = H_Lambda(Wl.slice(l), 
                      nul(l), CSD(l),
                      log_Const_prod_gamma(D,nul(l)));
  }
  
  arma::vec Z = .5 * ELDL + 
                 D * 0.5 * ( log( betal / (2 * arma::datum::pi)) - 1.0) -
                 H; // (10.77)
  
  return(arma::accu(Z));
}

// -----------------------------------------------------------------------------

double elbo_diff_S(arma::mat RHO_jk,
                arma::colvec ElnPI){
  
  arma::colvec mdot_k = arma::sum(RHO_jk, 0).t();
  double Z1 = arma::accu(mdot_k % ElnPI);
  double Z2 = arma::accu(RHO_jk % log(RHO_jk + 1e-12));
  return(Z1-Z2);
}


// -----------------------------------------------------------------------------

double elbo_diff_omega(arma::mat beta_star_lk,
                    arma::mat beta_lk){
  
  int L = beta_star_lk.n_rows;
  int K = beta_star_lk.n_cols;
  
  arma::mat E_ln_omega(L,K);
  double Konsts_p = arma::accu(ldirichlet_normconst_vec_cpp(beta_lk));
  double Konsts_q = arma::accu( ldirichlet_normconst_vec_cpp(beta_star_lk) );
  
  for(int k=0; k<K; k++){
    E_ln_omega.col(k) = E_log_DIR(beta_star_lk.col(k)); // L x K
  }
  
  double G_p =  Konsts_p + arma::accu( E_ln_omega % (beta_lk - 1.0) );
  double G_q =  Konsts_q + arma::accu( E_ln_omega % (beta_star_lk - 1.0) );
  return(G_p-G_q);
}

// -----------------------------------------------------------------------------

double elbo_conc_par_fiSAN(arma::colvec conc_hyper,
                           arma::colvec S_concDP){
  double pa =
    conc_hyper[0] * log(conc_hyper[1]) - lgamma(conc_hyper[0]) +
    (conc_hyper[0] - 1.0) * ( R::digamma(S_concDP[0]) - log(S_concDP[1]) ) -
    conc_hyper[1] * S_concDP[0]/S_concDP[1];

  double qa = S_concDP[0] * log(S_concDP[1]) - lgamma(S_concDP[0]) +
    (S_concDP[0] - 1.0) * (R::digamma(S_concDP[0])-log(S_concDP[1])) -  
    S_concDP[0];
  
  return(pa - qa);
}

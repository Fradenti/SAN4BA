#include "mvt_D_CAVI_UPDATES.h"
// --------------------------------------------------------------------------  1
arma::mat Update_Vk_DP_conc_cpp(double E_b,
                                arma::mat RHO_jk){

  int K = RHO_jk.n_cols;
  
  arma::colvec mk = (arma::sum(RHO_jk,0)).t();
  arma::colvec rev_cs_mk = reverse_cumsum_cpp(mk);

  arma::colvec a_tilde_vk      = mk        + 1.0;
  a_tilde_vk[K-1] = 1.0;
  arma::colvec b_tilde_vk      = rev_cs_mk + E_b;
  b_tilde_vk[K-1] = 1e-10;

  arma::colvec E_ln_Vk    = E_log_beta(a_tilde_vk, b_tilde_vk);
  arma::colvec E_ln_1mVk  = E_log_beta(b_tilde_vk, a_tilde_vk);
  arma::colvec sE_ln_1mVk = shift(E_ln_1mVk, +1);

  sE_ln_1mVk[0] = 0;

  arma::colvec CS_E_ln_1mVk = arma::cumsum(sE_ln_1mVk);
  arma::mat results(K,3);

  results.col(0) = a_tilde_vk;
  results.col(1) = b_tilde_vk;
  results.col(2) = E_ln_Vk + CS_E_ln_1mVk ;

  return(results);
}

// --------------------------------------------------------------------------- 2

arma::mat Update_beta_dirlk_cpp(arma::field<arma::mat> XI_ijl,
                                arma::mat RHO_jk,
                                arma::mat beta_lk){

  int L = beta_lk.n_rows;
  int J = XI_ijl.n_elem;
  int K = beta_lk.n_cols;
  
  arma::mat N_lj(L,J);
  arma::mat beta_star_lk(L,K);

  for(int j=0; j<J; j++){
    N_lj.col(j) = arma::sum(XI_ijl(j),0).t();
  }

  arma::mat Q_lk = N_lj * RHO_jk ;

  for(int k = 0; k<K; k++){

    beta_star_lk.col(k) = beta_lk.col(k) + Q_lk.col(k);

  }

  return(beta_star_lk);
}

// --------------------------------------------------------------------------- 3

arma::mat Update_RHOjk_cpp_fiSAN(arma::field<arma::mat> XI_ijl, // collection of  J objects: nj*L matrices
                                 arma::colvec ElnPI_k,
                                 arma::mat beta_star_lk){

  int L = beta_star_lk.n_rows;
  int J = XI_ijl.n_elem;
  int K = beta_star_lk.n_cols;
  
  arma::mat N_jl(J,L);

  for(int j=0; j<J; j++){
    N_jl.row(j) = arma::sum(XI_ijl(j),0);
  }

  arma::mat unn_log_RHO_jk(J,K);
  arma::mat log_RHO_jk(J,K);
  arma::mat RHO_jk(J,K);
  arma::mat E_ln_omega(L,K);

  for(int k=0; k<K; k++){
    E_ln_omega.col(k) =
      E_log_DIR(beta_star_lk.col(k)); // L x K
  }

  arma::mat Z = N_jl * E_ln_omega;

  for(int k = 0; k < K; k++){
    unn_log_RHO_jk.col(k) =  Z.col(k) +  ElnPI_k(k);
  }
  for(int j = 0; j < J; j++){
    log_RHO_jk.row(j) = unn_log_RHO_jk.row(j) - LogSumExp_cpp(unn_log_RHO_jk.row(j));
  }

  return(exp(log_RHO_jk));
}

// --------------------------------------------------------------------------- 4

arma::colvec Update_s_concentration_par_fiSAN(arma::colvec a_tilde_Vk,
                                        arma::colvec b_tilde_Vk,
                                        arma::colvec conc_hyper){

  int K = b_tilde_Vk.n_rows;
  arma::colvec upd_par(2);
  a_tilde_Vk.shed_row(K-1);
  b_tilde_Vk.shed_row(K-1);

  upd_par[0] = conc_hyper[0] + K - 1.0 ;
  upd_par[1] = conc_hyper[1] - arma::accu(E_log_beta(b_tilde_Vk,a_tilde_Vk));

  return(upd_par);
}

// -----------------------------------------------------------------------------

Rcpp::List Update_THETAl_cpp_mvt(arma::field<arma::mat> Y_grouped,
                                 arma::field<arma::mat> XI_ijl,
                                 arma::colvec m0,
                                 double beta0,
                                 double nu0,
                                 arma::mat W0, 
                                 arma::mat iW0){
  
  int D = W0.n_rows;
  int J = XI_ijl.n_elem;
  int L = XI_ijl(0).n_cols;
  
  
  arma::rowvec Nl(L, arma::fill::zeros);
  arma::mat SumY_l(D, L, arma::fill::zeros);
  arma::mat Ybarl(D, L, arma::fill::zeros);
  arma::cube Sl(D,D, L, arma::fill::zeros);
  arma::cube Sl_over_Nl(D,D, L, arma::fill::zeros);
  
  arma::mat ml(D,L);
  arma::rowvec betal(L);
  arma::rowvec nul(L);
  arma::cube Wl(D,D,L);
  
  
  for(int j=0; j <J; j++){
    arma::mat subY = Y_grouped[j];
    Nl      += arma::sum( XI_ijl(j), 0);
    SumY_l  += subY.t() * XI_ijl(j);  // D x L
  }
  
  arma::mat B0M0  = arma::repelem(beta0 * m0,1,L); // D x L
  betal           = Nl + beta0;
  nul             = Nl + nu0 ;
  arma::mat iBL   = arma::repelem(1.0 / betal, D, 1); // D x L
  ml              = ( B0M0 + SumY_l ) % ( iBL );

  
  for(int l=0; l<L; l++){
    
    if(Nl(l)>0){
      Ybarl.col(l) = SumY_l.col(l)/Nl(l);
    }
      
    for(int j=0; j <J; j++){
      arma::mat subY = Y_grouped[j].t(); // D x Nj
      for(int ii=0; ii<subY.n_cols; ii++){
        arma::mat temp = ( subY.col(ii) - Ybarl.col(l)) * 
                          (subY.col(ii) - Ybarl.col(l)).t();
        double xi = (XI_ijl(j))(ii,l);
        Sl.slice(l) += xi * temp;
      }
    }
    //Rcpp::Rcout<< Sl_Nl.slice(l) << ".....\nNl = " << Nl(l) << "\n.....\n";
    
    if(Nl(l)>0){
      Sl_over_Nl.slice(l) = Sl.slice(l)/Nl(l);
    }
    
    Wl.slice(l) = arma::inv_sympd(
        (iW0)+
        Sl.slice(l) +
        beta0*Nl(l)/(beta0+Nl(l)) *
        (Ybarl.col(l)-m0) * (Ybarl.col(l)-m0).t()
    );
    
  }
  //Rcpp::Rcout << "Sl = " << Sl;
  
  Rcpp::List results = Rcpp::List::create(
    Rcpp::_["ml"]  = ml,
    Rcpp::_["betal"] = betal.t(),
    Rcpp::_["nul"] = nul.t(),
    Rcpp::_["Wl"] = Wl,
    Rcpp::_["Ybar"] = Ybarl,
    Rcpp::_["Nl"] = Nl,
    Rcpp::_["Sl_over_Nl"] = Sl_over_Nl
  
  );
  return(results);
  
}

// -----------------------------------------------------------------------------

arma::field<arma::mat> Update_XIijl_cpp_fiSAN_mvt(arma::field<arma::mat> Y_grouped,
                                                  arma::mat RHO_jk,
                                                  arma::mat beta_star_lk,
                                                  arma::mat ml,
                                                  arma::colvec betal,
                                                  arma::colvec nul,
                                                  arma::cube Wl){
  
  int J = RHO_jk.n_rows;
  int K = RHO_jk.n_cols;
  int L = beta_star_lk.n_rows;
  arma::field<arma::mat> XI_ijl(J); // J different nj x L matrices
  arma::mat E_ln_omega(L,K);
  
  for(int k=0; k<K; k++){
    E_ln_omega.col(k) =
      E_log_DIR(beta_star_lk.col(k)); // L x K
  }
  
  arma::mat M_JL  =  RHO_jk * E_ln_omega.t();
  //to improve
  arma::rowvec logunn(L);
  
  
  for(int j= 0; j<J; j++){
    int Nj = Y_grouped[j].n_rows;
    arma::mat TT(Nj,L);
    
    for(int l= 0; l<L; l++){
      
      TT.col(l) = E_log_p_Y_Mtheta_cpp_mvt(Y_grouped[j],
             ml.col(l), betal(l), nul(l), Wl.slice(l));
    
    }
    arma::mat temp1 = TT;  // Nj x L
    arma::mat tempres(Nj,L);
    
    for(int i=0; i<Nj; i++){
      
      logunn = M_JL.row(j) + temp1.row(i);
      
      tempres.row(i) =  logunn - LogSumExp_cpp(logunn);
    }
    
    XI_ijl(j) = exp(tempres);
    
  }
  
  return(XI_ijl);
}

#include <RcppArmadillo.h>
#include "mvt_D_CAVI_UPDATES.h"
#include "mvt_E_ELBO_COMPONENTS.h"

// [[Rcpp::export]]
Rcpp::List main_vb_fiSAN_CP_cpp_mvtnorm(arma::field<arma::mat> Y_grouped,
                                        int const L,
                                        int const K,
                                        int const J,
                                        arma::field<arma::mat> XI_ijl,
                                        arma::mat RHO_jk,
                                        arma::colvec Nj,
                                        arma::colvec m0,
                                        double beta0,
                                        double nu0,
                                        arma::mat W0,
                                        arma::mat ml, // D x L
                                        arma::colvec betal,
                                        arma::colvec nul,
                                        arma::cube Wl,
                                        arma::colvec conc_hyper, // (s1, s2)
                                        double beta_bar,
                                        double epsilon,
                                        int maxSIM,
                                        bool verbose = 0){

  int D = ml.n_rows;
  int Q = maxSIM;
  // --------------------------------------------------------------   containers

  arma::mat beta_lk(L,K);
  beta_lk.fill(beta_bar);
  arma::mat beta_star_lk(L,K);
  arma::mat var_par_v(K,3);
  arma::colvec S_concDP(2);
  arma::cube Sl(D,D,L);
  arma::rowvec Nl(L);
  arma::mat Ybar(D,L);
  arma::colvec a_vk(K);
  arma::colvec b_vk(K);
  arma::colvec E_ln_PIk(K);
  arma::colvec  Elbo_val(maxSIM);
  arma::mat Elbo_components(maxSIM,7);

  // -----------------------------------------------------------  precomputables
  arma::mat iW0 = arma::inv_sympd(W0);
  double lCpl0  = log_Const_prod_gamma(D, nu0);
  double LlogB0 = L * logB_wish(W0, nu0, lCpl0);

  double a_tilde   = 1.0;
  double b_tilde   = conc_hyper[0]/conc_hyper[1];

  for(int ii = 0; ii<maxSIM; ii++){

    R_CheckUserInterrupt();

    // omega
    beta_star_lk = Update_beta_dirlk_cpp(XI_ijl,
                                         RHO_jk,
                                         beta_lk);
    // M
    XI_ijl = Update_XIijl_cpp_fiSAN_mvt(Y_grouped,
                                        RHO_jk,
                                        beta_star_lk,
                                        ml, betal, nul, Wl);

    // THETA
    Rcpp::List THETAl  = Update_THETAl_cpp_mvt(Y_grouped,
                                               XI_ijl,
                                               m0, beta0, nu0, W0, iW0);

    //arma::mat mltemp = THETAl["ml"];
    arma::mat ml_ = THETAl["ml"];
    ml = ml_;
    arma::colvec betal_ = THETAl["betal"];
    betal = betal_;
    arma::colvec nul_ = THETAl["nul"];
    nul = nul_;
    arma::cube Wl_ =  THETAl["Wl"];
    Wl = Wl_;
    arma::cube Sl_ =  THETAl["Sl_over_Nl"];
    Sl = Sl_;
    arma::mat Ybar_ =  THETAl["Ybar"];
    Ybar = Ybar_;
    arma::rowvec Nl_ =  THETAl["Nl"];
    Nl = Nl_;

    // V
    var_par_v = Update_Vk_DP_conc_cpp(b_tilde, RHO_jk);

    a_vk     = var_par_v.col(0);
    b_vk     = var_par_v.col(1);
    E_ln_PIk = var_par_v.col(2);

    // S
    RHO_jk = Update_RHOjk_cpp_fiSAN(XI_ijl,
                                    E_ln_PIk,
                                    beta_star_lk);

    S_concDP =  Update_s_concentration_par_fiSAN(a_vk,
                                                 b_vk,
                                                 conc_hyper);
    b_tilde = S_concDP[0]/S_concDP[1];

    // -------------------------------------------------------------------------
    //Rcpp::Rcout <<  1;
    Elbo_components(ii,0) = elbo_p_Y(XI_ijl, ml, betal, nul, Wl, Sl, Ybar, Nl);
    //Rcpp::Rcout <<  1;
    Elbo_components(ii,1) = elbo_diff_M_fiSAN(XI_ijl, RHO_jk, beta_star_lk);
    //Rcpp::Rcout <<  2;
    Elbo_components(ii,2) = elbo_diff_S(RHO_jk, E_ln_PIk);
    //Rcpp::Rcout <<  3;
    Elbo_components(ii,3) = elbo_diff_omega(beta_star_lk, beta_lk);
    //Rcpp::Rcout <<  4;
    Elbo_components(ii,4) = elbo_diff_v_CP(a_vk, b_vk, b_tilde, S_concDP);
    //Rcpp::Rcout <<  5;
    Elbo_components(ii,5) = elbo_p_THETA(m0, beta0, nu0,
                                         W0, iW0, lCpl0, LlogB0,
                                         ml, betal, nul, Wl)-
                            elbo_q_THETA(ml, betal, nul, Wl);
    //Rcpp::Rcout <<  6;
    Elbo_components(ii,6) = elbo_conc_par_fiSAN(conc_hyper, S_concDP);

    Elbo_val[ii] =  arma::accu(Elbo_components.row(ii));


     if(ii>1) {
       double diff = (Elbo_val[ii]-Elbo_val[ii-1]);
       if(verbose){
         Rcpp::Rcout << "Iteration #" << ii << " - Elbo increment: " << diff << "\n";
       }
       if( ((diff<0) & (std::fabs(diff) > 1e-5))){
         Rcpp::Rcout << "Warning! Iteration #" << ii << " presents an ELBO decrement!\n";
       }
       if( diff < epsilon ) {
         if(verbose){
           Rcpp::Rcout << "Final Elbo value: " << (Elbo_val[ii]) << "\n";
         }
         Q = ii;
         break;
       }
     }
  }

  if(Q == maxSIM){Q = Q-1;}

  arma::colvec ELBO_v2 = Elbo_val.rows(1,Q);
  arma::mat ELBO_C2 = Elbo_components.rows(1,Q);

  Rcpp::List results = Rcpp::List::create(
    Rcpp::_["ml"]  = ml,
    Rcpp::_["betal"]  = betal,
    Rcpp::_["nul"]  = nul,
    Rcpp::_["Wl"]  = Wl,
    Rcpp::_["Sl"]  = Sl,
    Rcpp::_["Elbo_val"] = ELBO_v2,
    Rcpp::_["XI"] = XI_ijl,
    Rcpp::_["RHO"] = RHO_jk,
    Rcpp::_["beta_bar_lk"] = beta_star_lk,
    Rcpp::_["a_tilde_k"] = a_vk,
    Rcpp::_["b_tilde_k"] = b_vk,
    Rcpp::_["conc_hyper"]  = S_concDP//,
    //Rcpp::_["components"]  = ELBO_C2
  );
  return(results);
}


#ifndef mvt_B_EXP_VALUES
#define mvt_B_EXP_VALUES

#include <RcppArmadillo.h>

arma::colvec E_log_beta(arma:: colvec a,
                        arma:: colvec b);

arma::colvec E_log_DIR(arma::colvec a);
  
arma::colvec E_log_p_Y_Mtheta_cpp_mvt(arma::mat Y,
                                      arma::colvec ml,
                                      double betal,
                                      double nul,
                                      arma::mat Wl);
#endif


#include "mvt_A_AUX.h"
#include "mvt_B_EXP_VALUES.h"

// slightly faster
arma::colvec E_log_beta(arma::colvec a,
                        arma::colvec b){
  
  int n = a.n_elem;
  arma::colvec res(n);
  for(int i=0; i<n; i++){
    res[i] = R::digamma(a[i]) - R::digamma(a[i] + b[i]);
  }
  return(res);
}

// -----------------------------------------------------------------------------


//slightly faster
arma::colvec E_log_DIR(arma::colvec a){
  
  int n = a.n_elem;
  arma::colvec res(n);
  double Sum_a = arma::accu(a);
  
  for(int i = 0; i < n; i++){
   res[i] = R::digamma( a[i] );   
  }
  
  return(res - R::digamma(Sum_a));
}

// -----------------------------------------------------------------------------

arma::colvec E_log_p_Y_Mtheta_cpp_mvt(arma::mat Y,
                                      arma::colvec ml,
                                      double betal,
                                      double nul,
                                      arma::mat Wl){
  
  int D = Y.n_cols;
  int N = Y.n_rows;
  
  double CSDg = Const_sum_digamma(D, nul);
  double ell1 = ElogDetLambda(Wl, CSDg);                   // \ell1 in algorithm
  
  arma::colvec fq(N);
  arma::mat DIFF = Y - arma::repelem(ml.t(), N, 1); // Nj x D
  arma::mat DIFFt = DIFF.t();
  for(int i=0; i<N; i++){
    arma::vec temp = (DIFF.row(i) * Wl * (DIFFt.col(i)));
    fq(i) = temp[0];
  }
  
  arma::colvec ell2 = ( - D * 1.0/(betal) - nul * fq ); // Nj x 1

  return(.5 * (ell1 + ell2));
}


#ifndef mvt_E_ELBO_COMPONENTS
#define mvt_E_ELBO_COMPONENTS

#include <RcppArmadillo.h>
#include "mvt_A_AUX.h"
#include "mvt_B_EXP_VALUES.h"
#include "mvt_C_NORM_CONST.h"


double elbo_diff_M_fiSAN(arma::field<arma::mat> XI_ijl,
                      arma::mat RHO_jk,
                      arma::mat beta_star_lk);

double elbo_p_Y(arma::field<arma::mat> XI_ijl,
                arma::mat ml,
                arma::colvec betal,
                arma::colvec nul,
                arma::cube Wl,
                arma::cube Sl,
                arma::mat Ybar,
                arma::rowvec Nl);

// -----------------------------------------------------------------------------

double elbo_diff_v_CP(arma::colvec a_tilde_k,
                   arma::colvec b_tilde_k,
                   double const b_tilde,
                   arma::colvec S_concDP);

// -----------------------------------------------------------------------------

double elbo_p_THETA(arma::colvec m0, double beta0, double nu0, 
                    arma::mat W0, arma::mat iW0, 
                    double lCpl0, double LlogB0,
                    arma::mat ml, arma::colvec betal,
                    arma::colvec nul, arma::cube Wl);
double elbo_q_THETA(arma::mat ml, arma::colvec betal,
                    arma::colvec nul, arma::cube Wl);

// -----------------------------------------------------------------------------

double elbo_diff_S(arma::mat RHO_jk,
                arma::colvec ElnPI);

// -----------------------------------------------------------------------------

double elbo_diff_omega(arma::mat beta_star_lk,
                    arma::mat beta_lk);

// -----------------------------------------------------------------------------

double elbo_conc_par_fiSAN(arma::colvec conc_hyper,
                           arma::colvec S_concDP);

// -----------------------------------------------------------------------------

#endif

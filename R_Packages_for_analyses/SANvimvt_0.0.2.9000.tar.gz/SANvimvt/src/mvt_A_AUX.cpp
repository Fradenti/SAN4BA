#include "mvt_A_AUX.h"

//------------------------------------------------------------------------------
double LogSumExp_cpp(arma::rowvec logX){
double a = max(logX);
return(  a + log(accu( exp( logX-a ) )));
}

//------------------------------------------------------------------------------
arma::colvec reverse_cumsum_cpp(arma::colvec X){
  return( accu(X) - arma::cumsum(X));
}

//------------------------------------------------------------------------------
double log_Const_prod_gamma(int D, double nu){
  double Q = 0.0;
  for( int d=1; d<(D+1); d++){
    Q += lgamma( ( nu + 1.0 - (d) ) * .5);
  }
  return(Q);
}

//----------------------------------------------------------------------------
double Const_sum_digamma(int D, double nu){
  double Q = 0.0;
  for( int d=1; d<(D+1); d++){
    Q += R::digamma( (nu + 1.0 - (d)) * .5);
  }
  return(Q);
}

//------------------------------------------------------------------------- B.79
double logB_wish(arma::mat W, double nu, double log_Const_prod_gamma){
  
  int D = W.n_cols;
  double p1 = - 0.5 * nu * log(arma::det(W));
  double p2 = (nu * D * .5) * log(2.0) + ( D * (D-1.0) / 4.0 ) * log(arma::datum::pi);
  return( p1 - p2 - log_Const_prod_gamma );
}

//------------------------------------------------------------------------- B.81
double ElogDetLambda(arma::mat W, double Const_sum_digamma){
  
  int D = W.n_cols;
  return( Const_sum_digamma + log(arma::det(W)) + D*log(2.0) );

  }

//------------------------------------------------------------------------- B.82
double  H_Lambda(arma::mat W, double nu, 
                 double Const_sum_digamma, 
                 double log_Const_prod_gamma){
  int D = W.n_cols;
  double ElDL = ElogDetLambda(W, Const_sum_digamma);
  double lnB = logB_wish(W, nu, log_Const_prod_gamma);
  return( - lnB - ( nu - D - 1.0) * 0.5 * ElDL + nu * D * 0.5);

  } 



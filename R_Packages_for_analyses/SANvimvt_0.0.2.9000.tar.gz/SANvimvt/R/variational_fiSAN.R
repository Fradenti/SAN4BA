#' Mean Field Variational Bayes estimation of fiSAN for multivariate data
#'
#' @param y Numerical vector of observations (required).
#' @param group Numerical vector of the same length of \code{y}, indicating the group membership (required).
#' @param maxL,maxK integers, the upper bounds for the observational and distributional clusters to fit, respectively
#' @param m0,beta0,nu0,W0 Hyperparameters on \eqn{(\mu, \Sigma) \sim NIW( m_0, \beta_0, \nu_0, W_0)}.
#' @param conc_hyperpar,conc_par Vectors of values used the concentration parameters of  of the stick-breaking representation for the distributional and observational DPs, respectively. 
#' The following two arguments can be passed. Specifically,
#' \describe{
#'   \item{\code{conc_hyperpar}}{a vector with 2 positive entries: \eqn{(s_1^\alpha,s_2^\alpha)}. 
#'   If a random concentration parameter \eqn{\alpha} is adopted, the specification is
#'  \eqn{\alpha \sim Gamma(s_1^\alpha,s_2^\alpha)}. Default set to unitary vector.}
#'   \item{\code{conc_par}}{a vector with one positive entry \eqn{\alpha}. Default is set to \code{NULL}. If specified, the previous argument is ignored
#'   and the two concentration parameters are assumed fixed and equal to \code{alpha}.}
#'  }
#' @param beta_bar the hyperparameter of the symmetric observational Dirichlet distribution.
#' @param epsilon the tolerance that drives the convergence criterion adopted as stopping rule
#' @param seed random seed to control the initialization.
#' @param maxSIM the maximum number of CAVI iteration to perform.
#' @param warmstart logical, if \code{TRUE}, the observational means of the cluster atoms are initialized with a k-means algorithm.
#' @param verbose logical, if \code{TRUE} the iterations are printed.
#'
#' @description \code{variational_mvt_fiSAN} is used to perform posterior inference under the finite-infinite shared atoms nested (fiSAN) model with multivariate Gaussian likelihood. 
#' The model uses a Dirichlet process mixture prior at the distributional level, and finite Dirichlet mixture at the observational one.
#' 
#'
#' @export
#' @importFrom stats rWishart
#'
#'@examples
#'\donttest{
#' set.seed(1234)
#'}
variational_mvt_fiSAN <- function(y, 
                    group,
                    maxL = 30,
                    maxK = 20,
                    m0 = rep(0,ncol(y)),
                    beta0 = 0.01,
                    nu0 = ncol(y)+5,
                    W0 = diag(ncol(y)),
                    conc_hyperpar = c(1,1),
                    conc_par = NULL,
                    beta_bar = .005,
                    epsilon = 1e-6,
                    seed = NULL,
                    maxSIM = 1e5,
                    warmstart = TRUE,
                    verbose = FALSE){


  L <- maxL
  K <- maxK

  if(nrow(y) != length(group)){
    stop("The number of observations and groups must match")
  }

  Nj <- tapply(group, group, length)
  J  <- max(group)

  if(is.null(seed)){seed <- round(stats::runif(1,1,10000))}
  # random init
  set.seed(seed)


  params <- list(y = y,
                group = group,
                Nj = Nj,
                J = J,
                K = K,
                L = L,
                m0 = m0, 
                beta0 = beta0,
                nu0 = nu0, 
                W0 = W0,
                beta_bar = beta_bar,
                epsilon = epsilon,
                seed = seed)

  Y_grouped <- list()
  for(j in 1:J){
    Y_grouped[[j]] <- y[group==j,] # this is a list, each element is a matrix with observations
  }

  # random init
  if(warmstart){
    ml  <- t(stats::kmeans(y,centers = L, algorithm="MacQueen",
                         iter.max = 100)$centers)
  }else{
    ml  <-   t(apply(y, 2, function(q) stats::runif(L, min((q)),max((q)))))
  }


  betal <- stats::rgamma(L,1,10)
  nul   <- ncol(y)+stats::rgamma(L,1,1)
  Wl    <- stats::rWishart(L,nu0,W0)

  ###############################################################################################
  XI_ijl = list()
  for(j in 1:J){
    log.XI_il  <- array(stats::rbeta( Nj[j] * L, 1, 1),dim = c( Nj[j], L))
    Z           <- apply(log.XI_il, c(1), function(x) matrixStats::logSumExp(x))
    XI_ijl[[j]] <- exp(sapply(1:L, function(qq) log.XI_il[,qq]-Z,simplify = "array"))
  }
  ###############################################################################################
  if(K<J){
    log.RHO_jk <- matrix(stats::rbeta(J*K,1,1),J,K)
    Z2         <- apply(log.RHO_jk, c(1), function(x) matrixStats::logSumExp(x))
    RHO_jk     <- exp(sapply(1:K, function(qq) log.RHO_jk[,qq]-Z2,simplify = "matrix"))
  }else if(K==J){
    RHO_jk     <- diag(J)
  }else{
    RHO_jk     <- cbind(diag(J), matrix(0,J,K-J))
  }

    start <- Sys.time()
    results <- main_vb_fiSAN_CP_cpp_mvtnorm(
      Y_grouped = Y_grouped,
      L = L,
      K = K,
      J = J,
      XI_ijl = XI_ijl,
      RHO_jk = RHO_jk,
      Nj = Nj,
      m0 = m0,
      beta0 = beta0,
      nu0 = nu0,
      W0 = W0,
      ml = ml,
      betal = betal,
      nul = nul,
      Wl = Wl,
      conc_hyper = conc_hyperpar,
      beta_bar = beta_bar,
      epsilon = epsilon,
      maxSIM = maxSIM,
      verbose = verbose
    )
    end <- Sys.time()

  output <- list("model" = "fiSAN",
                 "params" = params,
                 "sim"= results,
                 "time" = end - start)
  
  class(output$sim) <- "fiSANvi"
  structure(output, class = c("SANmvt",class(output)))
  
}

